# _*_ coding：utf-8 _*_
# @Author   :cjj
# @time		:2018/6/27 9:12
# @File 	:__init__.py.py
# @Software :PyCharm

# 用于存放报告，测试结束时会自动生成报告到此目录下
